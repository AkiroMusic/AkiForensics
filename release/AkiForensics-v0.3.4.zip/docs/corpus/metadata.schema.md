# metadata.jsonl line schema 每行 schema

{"sha256": "<file hash>", "path": "corpus/ai/suno/x.wav", "class": "ai/suno",
 "generator": "suno|human-daw|unknown", "generator_version": "string|null",
 "genre": "string", "duration_s": 0.0, "sample_rate": 44100,
 "bits_per_sample": 16, "channels": 2, "delivery_chain": "native|mp3-to-flac|...",
 "license": "private|cc|owned", "added": "2026-11-07"}
