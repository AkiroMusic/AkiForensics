# AkiForensics Reference Corpus — Manifests & Structure (versioned)

This directory is the VERSIONED copy of the corpus structure template and
manifest schema. Actual audio stays LOCAL under gitignored `corpus/`; only
manifests (hashes, provenance, licenses) may ever be committed. Initialize
a fresh checkout's `corpus/` from this template (run_acceptance.py does it
in a temp dir automatically).

Audio files live LOCALLY only (`corpus/` is gitignored). The public repo may
carry manifests (hashes, provenance, licenses) — never unauthorized audio.

Structure 语料结构（GPT-R4 §十一 adopted, hybrid class included）:

```
corpus/
├── human/
│   ├── daw_quantized/        # 量化制作（人类基线）
│   ├── daw_unquantized/      # 不量化实录（假阳性最大来源，最重要）
│   ├── loop_based/           # loop/采样器工作流
│   └── mp3_to_flac/          # 人工母带走有损交付（交付链对照组）
├── ai/
│   ├── suno/                 # Suno Reference Set（7 首 commercial demos 已在库）
│   ├── other_generators/     # Udio / 其他生成器（防单管线过拟合）
│   └── ai_post_daw/          # AI 生成后 DAW 处理
└── hybrid/                   # 现实中大量存在，不能用二分类解释
    ├── ai_vocals_human_instrumental/
    └── human_stems_ai_processing/
```

Discipline 语料纪律（GPT-R3/R4 adopted）:
1. 同一作品的转码版本绝不同时出现在两个类别（防泄漏）。
2. 每个文件登记 `manifests/metadata.jsonl`：sha256、来源、生成器/版本、曲风、时长、许可。
3. 训练/验证按作品隔离（`manifests/splits.json`）。
4. `calibrate` 输出是 THRESHOLD PROPOSAL —— 人工复核后手动升版本号。
